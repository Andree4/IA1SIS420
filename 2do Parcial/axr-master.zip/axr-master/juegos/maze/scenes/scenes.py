from enum import Enum


class Scenes(Enum):
    MENU = 1
    GAME = 2
    CREDITS = 3
