from .load_image import load_image
from .load_sound import load_sound