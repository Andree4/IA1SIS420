class Player():
    def __init__(self):
        self.symbol = -1
