from enum import Enum


class Players(Enum):
    HUMAN = 1
    AGENT_E_GREEDY = 2
    AGENT_UCB = 3
    AGENT_GRADIENT_ASCENT = 4
